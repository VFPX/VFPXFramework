* Include other include files.

#include Foxpro.h

* Control character constants.

#define ccCRLF		chr(13) + chr(10)
#define ccCR		chr(13)
#define ccLF		chr(10)
#define ccNULL	chr(0)
#define ccTAB		chr(9)
